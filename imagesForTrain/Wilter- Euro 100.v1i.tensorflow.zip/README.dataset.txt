# Wilter- Euro 100 > 2022-08-06 5:26pm
https://universe.roboflow.com/pp-deteccin-de-objetos/wilter--euro-100

Provided by a Roboflow user
License: CC BY 4.0

