# counterfeit detecetion > 2023-03-18 9:33pm
https://universe.roboflow.com/kapaznik-ttcwo/counterfeit-detecetion

Provided by a Roboflow user
License: CC BY 4.0

