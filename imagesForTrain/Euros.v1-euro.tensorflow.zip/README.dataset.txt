# Euros > Euro
https://universe.roboflow.com/pp-deteccin-de-objetos/euros-7khiv

Provided by a Roboflow user
License: CC BY 4.0

