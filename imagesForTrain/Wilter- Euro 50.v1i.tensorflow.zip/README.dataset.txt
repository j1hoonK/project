# Wilter- Euro 50 > 2022-08-06 5:02pm
https://universe.roboflow.com/pp-deteccin-de-objetos/wilter--euro-50

Provided by a Roboflow user
License: CC BY 4.0

