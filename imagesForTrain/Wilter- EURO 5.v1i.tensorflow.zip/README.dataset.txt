# Wilter- EURO 5 > 2022-11-06 2:50pm
https://universe.roboflow.com/pp-deteccin-de-objetos/wilter-euro-5

Provided by a Roboflow user
License: CC BY 4.0

