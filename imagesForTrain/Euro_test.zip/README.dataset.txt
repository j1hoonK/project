# 414-471 > 414-417_named
https://universe.roboflow.com/filippo-comastri/414-471

Provided by a Roboflow user
License: CC BY 4.0

