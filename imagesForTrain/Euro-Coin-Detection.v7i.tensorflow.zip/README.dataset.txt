# Euro-Coin-Detection > 2022-06-23 3:27pm
https://universe.roboflow.com/ownsoft-technologies/euro-coin-detection

Provided by a Roboflow user
License: CC BY 4.0

